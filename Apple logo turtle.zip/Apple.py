import turtle
from turtle import *

width(0)
bgcolor('black')
color('gray')
begin_fill()

left(160)
circle(100,100)
circle(200,60)
circle(40,90)
circle(-40,100)
circle(40,100)
circle(200,30)
left(90)
circle(-70,150)
left(120)
circle(160,55)
right(110)
end_fill()
up()
forward(25)
begin_fill()
down()
circle(-100,90)
right(90)
circle(-100,90)

end_fill()

turtle.done()